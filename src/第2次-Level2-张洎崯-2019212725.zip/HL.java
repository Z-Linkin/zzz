public class HL {


    public static void main(String[] args) {
        System.out.println("" +
                "\t\t\t\t\t\t\t\t\t*\n" +
                "\t\t\t\t\t\t\t\t**\n" +
                "\t\t\t\t\t\t\t***\n" +
                "\t\t\t\t\t\t****\n" +
                "\t\t\t\t\t*****\n" +
                "\t\t\t\t******\n" +
                "\t\t\t*******\n" +
                "\t\t********\n" +
                "\t*********\n" +
                "**********\n"+
                "\t*********\n"+
                "\t\t********\n"+
                "\t\t\t*******\n" +
                "\t\t\t\t******\n" +
                "\t\t\t\t\t*****\n" +
                "\t\t\t\t\t\t****\n" +
                "\t\t\t\t\t\t\t***\n" +
                "\t\t\t\t\t\t\t\t**\n" +
                "\t\t\t\t\t\t\t\t\t*\n" );
    }
}