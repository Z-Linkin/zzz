package Card;

public class CardTable {
    private int tableMoney;

    public CardTable(int money){
        this.tableMoney=money;
    }

    public int getTableMoney(){
        return tableMoney;
    }
}
