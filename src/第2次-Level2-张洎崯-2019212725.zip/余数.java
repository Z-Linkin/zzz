public class 余数{

    public static void main(String[] args) {
     final int sum=555555 ;
     int i;

     for (i=999;sum%i!=0;i--);
        System.out.println("555555的三位最大约束为"+i);
    }
}
